<?php 
		$Emeaning = "";
	$Sword = "";
	$Smeaning = "";
	include 'db_connection.php';

?>
<?php include 'menus.inc';?>
<!DOCTYPE html>
<html>
<head>
<title>Glossary</title>
</head>

<body>
<div class="col-md-11" style='margin-left: 65px'>
	 <div class="well">
      <p class="lead">
        <div align='left'>
	<div class="navbar navbar-default">
	             <ul class="nav navbar-nav navbar-left">
                    <li class="nav" style="color:white"><h2>Search Computer Science Terms</h2></li>
     
                </ul>
	</div>

<form action = "task2.php" method = "POST">

    <div class="form-group">
	<label for="word"> Glossary in English:</label>
		<input class="form-control" type = "text" id="word" name = "Eword" placeholder="Search a word in English"> 
		</div>
<button input type = "submit" name = "search" class="btn btn-success">Search</button><br/>
<hr>

 <table class ="table table-striped" border='0px'  width='70%' align='center'>
            <tr style="color:#18bc9c">
                  
                <td>
                    <i><b>English Meaning</br></i>
                </td>                 
                <td>
                    <i><b>Sepedi/Setswana Meaning</br></i>
                </td>
				 <td>
                    <i><b>Sepedi/Setswana Word</br></i>
                </td>
				
            </tr>
			<tr>                 
                <td>
                    <?php echo $Emeaning; ?>
                </td>                 
                <td>
                    <?php echo $Sword; ?>
                </td>
				 <td>
                    <?php echo $Smeaning; ?>
                </td>
				
            </tr>
			<tr>
			<td></td>
			<td></td>
			<td></td>
			
			</tr>
			
</table>

</form>
</div>
</div>
</div>
</body>
<hr/>
<hr/>
<iframe src="task2.txt" height="400" width="1200">
</html>